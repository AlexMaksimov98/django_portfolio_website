from django.contrib import admin
from .models import *

admin.site.register(Skill)
admin.site.register(Degree)
admin.site.register(Project)
admin.site.register(Message)
admin.site.register(Dish)
admin.site.register(SkillType)